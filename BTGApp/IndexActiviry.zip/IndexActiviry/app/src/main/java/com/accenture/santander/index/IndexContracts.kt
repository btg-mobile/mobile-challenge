package com.accenture.santander.index

class IndexContracts {

    interface IndexPresenterInput {
        fun verifyAuth()
    }

    interface IndexInteractorInput {

    }

    interface IndexPresenterOutput {
        fun setup()
    }

    interface IndexInteractorOutput {

    }
}