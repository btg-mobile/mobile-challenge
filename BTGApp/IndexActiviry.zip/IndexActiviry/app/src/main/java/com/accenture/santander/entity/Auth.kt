package com.accenture.santander.entity

data class Auth(
    var userAccount: UserAccount,
    var error: Error
)