package com.accenture.santander.index

class IndexInteractor(
    private val iIndexInteractorOutput: IndexContracts.IndexInteractorOutput
) : IndexContracts.IndexInteractorInput{

}