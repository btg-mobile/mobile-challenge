package com.accenture.santander.viewmodel

data class UserViewModel(
    var login: String = "",
    var password: String = ""
)