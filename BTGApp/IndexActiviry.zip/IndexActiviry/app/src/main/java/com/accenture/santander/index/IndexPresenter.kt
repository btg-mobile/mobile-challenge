package com.accenture.santander.index

import org.junit.Test
import org.junit.Assert.*

class IndexPresenter(
    private val iIndexPresenterOutput: IndexContracts.IndexPresenterOutput
) : IndexContracts.IndexPresenterInput, IndexContracts.IndexInteractorOutput {

    private val iIndexInteractorInput: IndexContracts.IndexInteractorInput = IndexInteractor(this)

    @Test
    override fun verifyAuth() {
        assertNotNull(iIndexInteractorInput)
    }
}