package com.accenture.santander.remote.connect

/**
 * Created by dev on 13/05/2018.
 */
class URL {
    companion object {

        private val URL_SERVECE = "https://bank-app-test.herokuapp.com"
        private val NAME_SERVICE = "/apis/"
        val WEB_SERVICE = URL_SERVECE + NAME_SERVICE
    }
}