package com.accenture.santander.recyclerview.viewholder

import androidx.recyclerview.widget.RecyclerView
import com.accenture.santander.databinding.ItemStatementHeaderBinding

class StatementHeaderViewHolder(val binding: ItemStatementHeaderBinding) : RecyclerView.ViewHolder(binding.root)