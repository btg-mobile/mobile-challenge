package com.accenture.santander.interector.remote.service

interface IConnect {
    fun verifyConnection(): Boolean
}