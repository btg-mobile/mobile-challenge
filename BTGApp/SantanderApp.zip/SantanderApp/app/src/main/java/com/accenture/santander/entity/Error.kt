package com.accenture.santander.entity

data class Error(
    var code: Int = 0,
    var message: String = ""
)